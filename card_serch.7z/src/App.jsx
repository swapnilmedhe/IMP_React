import React, { Component } from 'react';
import PeopleCard from "./PeopleCard";
import PaginationExample from "./Pagination";
import CardExp from "./CardExp";

import './App.css';


const people = [
  {
    id: 1,
    first: "swapnil",
    last: "medhe",
    age: 23
  },
  {
    id: 2,
    first: "rakesh",
    last: "patil",
    age: 22
  },
  {
    id: 3,
    first: "shivam",
    last: "raje",
    age: 12
  },
  {
    id: 4,
    first: "pranali",
    last: "chaudhari",
    age: 24
  }
]



//serching function 
function serchingFor(term) {
  console.log("tearm" + term);

  return function (x) {
    console.log("X" + x);
    return x.first.toLowerCase().includes(term.toLowerCase()) || !term;
  }

}

class App extends Component {

  constructor(props) {
    super(props);
    this.state = {
      people: people,
      term: ''
    }
    this.searchHandler = this.searchHandler.bind(this);
  }

  removehandler = (id) => {
    console.log("remove clicl" + id);
    const clonepeople = [...this.state.people, newpeople];
    const newpeople = people.splice(id, 1);
    //id.priventDefault();
    this.setState({
      people: clonepeople
    });

    

  }

  searchHandler = (event) => {
    console.log([event.target.value])
    this.setState({
      term: event.target.value
    });
  }


  render() {
    const data = this.state.people.filter(serchingFor(this.state.term)).
      map((per) =>
      // <div key={per.id}>{per.first} {per.last} {per.age}</div>
      {
        return <PeopleCard data={per} />
      }
      )


    const carddata = this.state.people.
      map((per) =>
      // <div key={per.id}>{per.first} {per.last} {per.age}</div>
      {
        return <CardExp data={per} remove={(id) => this.removehandler(id)} />
      }
      )

    return (
      <div className="App">
        <form>
          <lable>Search </lable>
          <input type="text" icon="serach" value={this.state.term} onChange={this.searchHandler} />
        </form>
        {
          data
        }

        {carddata}

        <PeopleCard data={data} />
        <PaginationExample />
      </div>
    );
  }
}

export default App;
