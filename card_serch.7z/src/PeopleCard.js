import React, { Component } from 'react';
import { Card, Icon, Image, Button } from 'semantic-ui-react';


const PeopleCard = (props) => {
    console.log(props);

    return (
        <Card>
            <Image src='http://padmashree.org/wp-content/uploads/2016/07/user-icon-image-download.jpg' />
            <Card.Content>
                <Card.Header>     <div>  {props.data.id}</div>
                    <div>{props.data.first} </div>
                    <div>{props.data.last} </div>
                    <div> {props.data.age} </div>
                </Card.Header>

                {/* <Card.Description>
          
          </Card.Description> */}
                <div className='ui two buttons'>
                    <Button basic color='green'>
                        Approve
          </Button>
                    <Button basic color='red' onClick={() => { props.remove(props.data.id) }}>
                        Decline
          </Button>
                </div>
            </Card.Content>

        </Card>
    )

}

export default PeopleCard
